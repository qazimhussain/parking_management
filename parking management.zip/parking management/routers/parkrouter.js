const router=require('express').Router()

const Parking=require('../models/parking')

router.get('/',async(req,res)=>{

    const parkingRecord= await Parking.find({status:'IN'}).sort({vin:-1})

    let parkhours=[]

    let parkmins=[]

    let parkdate=[]

    parkingRecord.forEach(elem=>{
        let date=new Date(elem.vin);
        let localdate=date.toLocaleDateString()
        let hour=date.getHours()
        let min=date.getMinutes()



        parkhours.push(hour)
        parkmins.push(min)

        parkdate.push(localdate)
        
    })



    res.render('index',{parkingRecord,parkhours,parkmins,parkdate})
})

router.get('/park_vehicle',(req,res)=>{
    res.render('add_vehicle.ejs')
})


router.post('/add_new_vehicle',(req,res)=>{
    const {vno,vtype}=req.body

    if(vno.length!==0)
    {
        const vin=new Date()

        const park_record=new Parking({vno:vno,vtype:vtype,vin:vin,status:'IN',vout:'',amount:0})
    
        park_record.save()
        res.redirect('/')
    }

    else{
        res.redirect('/park_vehicle')

    }

    

})

router.post('/out_vehicle/:id',async(req,res)=>{
    const id=req.params.id;

    let parkrecord=await Parking.findById(id)

    if(parkrecord.status==='IN')
    {

    let outdate=new Date()
    let outtime=outdate.getTime()

    let indate=new Date(parkrecord.vin)
    let intime=indate.getTime()

    let actualtime=Math.round((outtime-intime)/(1000*60)) //minutes
     
    let amount=null

    if(parkrecord.vtype=='2w')
    {

        amount=actualtime*0.3

    }
    else if(parkrecord.vtype=='3w')
    {
        amount=actualtime*0.4

    }

    else if(parkrecord.vtype=='4w')
    {
        amount=actualtime*0.6


    }

    else{
        amount=actualtime*0.9
    }


    amount=Math.round(amount)

    await Parking.findByIdAndUpdate(id,{amount:amount,status:'OUT',vout:outdate})

    parkrecord=await Parking.findById(id)




    const parkout=outdate.toLocaleDateString()

    const parkin=indate.toLocaleDateString()

    console.log(actualtime,amount,parkrecord,parkout,parkin,parkout===parkin)

    let parkhours=[]

    let parkmins=[]

    let parkdate=[]

    let outparkhours=[]
    let outparkmins=[]
    let outparkdate=[]

    
        let date=new Date(parkrecord.vin);
        let localdate=date.toLocaleDateString()
        let hour=date.getHours()
        let min=date.getMinutes()

        let parkoutdate=new Date(parkrecord.vout)
        let localoutdate=parkoutdate.toLocaleDateString()
        let outhour=parkoutdate.getHours()
        let outmin=parkoutdate.getMinutes()






        

        outparkdate.push(localoutdate)
        outparkmins.push(outmin)
        outparkhours.push(outhour)



        parkhours.push(hour)
        parkmins.push(min)

        parkdate.push(localdate)
        


    


    res.render('parkingprint.ejs',{parkrecord,actualtime,parkout,parkin,parkhours,parkdate,parkmins,outparkdate,outparkhours,outparkmins})
}
else{
    res.redirect('/')
}



})

router.get('/history',async(req,res)=>{
    const parkingRecord= await Parking.find({status:'OUT'}).sort({vout:-1})

    let parkhours=[]

    let parkmins=[]

    let parkdate=[]

    let outparkhours=[]
    let outparkmins=[]
    let outparkdate=[]

    parkingRecord.forEach(elem=>{
        let date=new Date(elem.vin);
        let localdate=date.toLocaleDateString()
        let hour=date.getHours()
        let min=date.getMinutes()
        
        let outdate=new Date(elem.vout)
        let localoutdate=outdate.toLocaleDateString()
        let outhour=outdate.getHours()
        let outmin=outdate.getMinutes()






        parkhours.push(hour)
        parkmins.push(min)

        parkdate.push(localdate)

        outparkdate.push(localoutdate)
        outparkmins.push(outmin)
        outparkhours.push(outhour)
        
    })



    res.render('history',{parkingRecord,parkhours,parkmins,parkdate,outparkdate,outparkhours,outparkmins})
})

module.exports=router