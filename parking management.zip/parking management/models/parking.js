const mongoose=require('mongoose')

const parkingSchema=mongoose.Schema({
    vno:String,
    vtype:String,
    vin:Date,
    amount:String,
    vout:Date,
    status:String

})

module.exports=mongoose.model('parking',parkingSchema)